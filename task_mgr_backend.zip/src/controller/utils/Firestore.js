// Replace with actual Firebase storage init when available.
module.exports = { storage: undefined };