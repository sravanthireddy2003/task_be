// src/workflow/workflowRoutes.js

const workflowController = require('./workflowController');

module.exports = workflowController;