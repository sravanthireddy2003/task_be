module.exports = require('../services/passwordPolicy');
