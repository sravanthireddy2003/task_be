// Shim re-export to new service path
module.exports = require('../services/emailService');
