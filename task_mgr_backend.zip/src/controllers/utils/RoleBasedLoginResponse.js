// Re-export RoleBasedLoginResponse from singular controller path
module.exports = require(__root + 'controller/utils/RoleBasedLoginResponse');
