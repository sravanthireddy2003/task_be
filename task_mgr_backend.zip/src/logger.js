// Shim to keep legacy require(__root + 'logger') working
module.exports = require('../logger');
