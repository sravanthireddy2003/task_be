// Shim to keep legacy require(__root + 'multer') working
module.exports = require('../multer');
