
module.exports = require('../logger');
