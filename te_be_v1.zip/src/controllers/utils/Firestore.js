
module.exports = require(__root + 'controller/utils/Firestore');
