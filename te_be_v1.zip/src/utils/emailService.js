
module.exports = require('../services/emailService');
