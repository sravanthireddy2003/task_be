module.exports = require('./config/db');
