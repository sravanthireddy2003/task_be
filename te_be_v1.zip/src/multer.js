
module.exports = require('../multer');
