

const workflowController = require('./workflowController');

module.exports = workflowController;