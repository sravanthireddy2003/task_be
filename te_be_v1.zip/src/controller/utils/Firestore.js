
module.exports = { storage: undefined };